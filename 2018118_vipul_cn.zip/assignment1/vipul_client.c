//vipul_client.c

//client.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <ctype.h>

void error(const char *msg){
	perror(msg);
	exit(0);

}  

int main(int argc, char *argv[]){
	int sockfd ,portno,n;
	struct sockaddr_in serv_addr;
	struct hostent *server;

	char buffer[255];
	if(argc<3){
		fprintf(stderr, "Usage%shostname port\n",argv[0] );
		exit(1);
	}

	portno=atoi(argv[2]);
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0){
		error("ERROR opening sock");


	}
	else{
		printf("Socket created.....\n");
	}

	server = gethostbyname(argv[1]);
	if(server==NULL){
		fprintf(stderr, "Error no such host.\n");

	}
	else{
		printf("Congrats!!!!!Host Found.....\n");
	}
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	bcopy((char *)server->h_addr,(char *) &serv_addr.sin_addr.s_addr ,server->h_length);
	serv_addr.sin_port=htons(portno);
	if(connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
		error("Connection Failed");
	}
	else{
		printf("Connection started......\n");
	}
	bzero(buffer,255);
	char *Name_of_File;

	// int flag=1;
	// // printf("Please Enter .txt file name :");
	// //for file asking
	// // while(flag==1){
	
	// fgets(buffer,255,stdin);
	// // printf("Enter file name in .txt:");
	// n=write(sockfd, buffer,strlen(buffer));
	// if(n<0){
	// 	error("ERROR on writing");
	// }
	// // bzero(buffer,255);
	// n=read(sockfd,buffer,255);
	// if(n<0){
	// 	error("Error on reading");


	// }


	//code for sending file name to be search
	fgets(buffer,255,stdin);
	//printf("Enter file name in .txt:");
	n=write(sockfd, buffer,strlen(buffer));
	Name_of_File=buffer;
	if(n<0){
		error("ERROR on writing");
	}

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0){
		error("Error on reading");
	}



	// Name_of_File=buffer;
	//printf("file name is: %s",buffer );
	// flag=0;

// }
	printf("eter the file name");
	gets(Name_of_File);
	strcat(Name_of_File,"_received.txt");

	printf("%s", Name_of_File);

	// FILE *f;

	// char Name_of_File[128];

	// printf("Please Enter .txt file name :");
	// scanf("%123s",Name_of_File);
	// printf("Intializing......");
	// strcat(Name_of_File,".txt");


	// int words=0;
	// char c;
	
	// if(f=fopen(Name_of_File,"r")){
	// 	printf("File Found....\n");
	// 	printf("Process has started of sending file .............\n");
	// 	while((c=getc(f))!=EOF)
	// {
	// 	fscanf(f,"%s",buffer);
	// 	if(isspace(c)|| c=='\t'){
	// 		words++;
	// 	}
		
	// }
 //    }
	// else{
	// 	printf("File not found......!!!!!\n");

	// }

	// write(sockfd,&words,sizeof(int));
	// rewind(f);
	// char ch;
	// while(ch !=EOF)
	// {
	// 	fscanf(f,"%s",buffer);
	// 	write(sockfd,buffer ,255);
	// 	ch=fgetc(f);


	// }

	// printf("File have been successfully sent. Thank you!\n");

		FILE *fp;
	int ch=0;
	char *prince="yes";
	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0){
		error("Error on reading");
	}

	// printf("File found:%s\n",buffer);
	if(strcmp(buffer,prince)==0){
		fp = fopen(Name_of_File,"a");

		int words;
		read(sockfd,&words,sizeof(int));

		printf("File receiving started.....\n");
		while(ch!=words)
		{
			read(sockfd,buffer,255);
			fprintf(fp, "%s ",buffer );
			ch++;

		}
		printf("file has been received succesfully . It is saved by name vipul_received.txt .");
	 	// close(newsockfd);

	}
	else {
		printf("File not found sorrry .....!!!!");

	}

	
 	// close(sockfd);



	
	close(sockfd);
	return(0);

}
