//server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <ctype.h>



void error(const char *msg){
	perror(msg);
	exit(1);

}  


int main(int argc,char * argv[])
{
	if(argc<2){
		fprintf(stderr,"port no. not provided. Program terminated\n");
		exit(1);
	}

	int sockfd , newsockfd ,portno,n;
	char buffer[255];

	struct sockaddr_in serv_addr ,cli_addr;
	socklen_t clilen;

	sockfd = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0){
		error("Error opening socket.");
	} 
	else{
		printf("Socket created....\n");
	}

	bzero((char *) &serv_addr, sizeof(serv_addr));

	portno=atoi(argv[1]);

	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=INADDR_ANY;
	serv_addr.sin_port=htons(portno);

	if(bind(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr))<0){
		error("Binding failed");
	}
	else{
		printf("Binding Completed.....\n");
	}


	listen(sockfd , 5);

	clilen=sizeof(cli_addr);

	newsockfd = accept(sockfd , (struct sockaddr *)&cli_addr ,&clilen);

	if(newsockfd<0){
		error("Error on accept");
	}
	else{
		printf("Connection Established....\n");
	}

	char *Name_of_File;
	//code for reading file name
	// int flag=1;
	// // while(flag==1){
	// // bzero(buffer,255);
	// // fgets(buffer,255,stdin);
	// //n=write(newsockfd,"Please Enter file name .txt form:",strlen("Please Enter file name .txt form:"));
	// // if(n<0){
	// // 	error("Error on writting");
	// // }
	// n=read(newsockfd,buffer,255);
	// if(n<0){
	// 	error("Error on reading");
	// }
	// printf("File name received..\n");
	// printf("File name is: %s\n",buffer);

	// bzero(buffer,255);

	// reading file name to search

	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0){
		error("Error on reading");
	}

	printf("File Name :%s\n",buffer);

	//  bzero(buffer,255);
	//  n=write(sockfd, buffer,strlen(buffer));
	// if(n<0){
	// 	error("ERROR on writing");
	// }
	// fgets(buffer,255,stdin);
	printf("File name received!! Initializing the searching....\n");

	

	
	// strcat(buffer,".txt");
	strcpy(Name_of_File,buffer);
	// printf("%s",Name_of_File);
	// ?flag=0;
	// char vipulb[256]
	// strcat(vipulb,bu)

		
	// }
////new code here 
	FILE *f;

	

	// printf("Please Enter .txt file name :");
	// scanf("%123s",Name_of_File);
	char vk[15];
	strcpy(vk,".txt");
	// printf("Enter the file extension");
	// fgets(vk);
	
	
	printf("Intializing......   ");
	strcat(Name_of_File,vk);  
	 printf("%s",Name_of_File );


	int words=0;
	char c;
	f=fopen(Name_of_File,"r+");
	




		// bzero(buffer,255);
		// strcat(buffer,"no");
		// n=write(sockfd, buffer,strlen(buffer));
		// if(n<0){
		// 	error("ERROR on writing");
		// }
		// bzero(buffer,255);
		// n=read(sockfd,buffer,255);
		// if(n<0){
		// 	error("Error on reading");
		// }

		// 	printf("File not found......!!!!!\n");


		
  //   }
	// else{
		bzero(buffer,255);
		// fgets(buffer,255,stdin);
	//printf("Enter file name in .txt:");
		strcat(buffer,"yes");
		// printf("%s\n",buffer );
		n=write(sockfd, buffer,strlen(buffer));
		if(n<0){
			error("ERROR on writing");
		}
		bzero(buffer,255);
		n=read(sockfd,buffer,255);
		if(n<0){
			error("Error on reading");
		}



			printf("File Found....\n");
			printf("Process has started of sending file .............\n");
			while((c=getc(f))!=EOF)
		{
			fscanf(f,"%s",buffer);
			if(isspace(c)|| c=='\t'){
				words++;
			}
			
		}

	

	// }

	write(newsockfd,&words,sizeof(int));
	rewind(f);
	char ch;
	while(ch !=EOF)
	{
		fscanf(f,"%s",buffer);
		write(newsockfd,buffer ,255);
		ch=fgetc(f);


	}

	printf("File have been successfully sent. Thank you!\n");
	





	// FILE *fp;
	// int ch=0;
	// fp = fopen("mytext_received.txt","a");

	// int words;
	// read(newsockfd,&words,sizeof(int));

	// printf("File receiving started.....\n");
	// while(ch!=words)
	// {
	// 	read(newsockfd,buffer,255);
	// 	fprintf(fp, "%s ",buffer );
	// 	ch++;

	// }
	// printf("file has been received succesfully . It is saved by name mytext_received\n");
 	close(newsockfd);
 	close(sockfd);
	return(0);

}